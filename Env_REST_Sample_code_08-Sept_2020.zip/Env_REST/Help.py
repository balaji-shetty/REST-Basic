Download POSTGRE sql from
https://www.tecmint.com/install-postgresql-on-ubuntu/
----------------------------------------------


Create Postgre Database.

'NAME': 'mydb',
        'USER': 'myuser',
        'PASSWORD': 'mypass',

----------------
SOURCE- CODE -Downloaded from

https://github.com/agustincastro/DjangoRestAPI-Restaurant

Env_REST is Environment Folder here and it contains main project
of name  DjangoRestAPI-Restaurant
--------------------------------------------------------------



    Have python3 installed
    Initialize a new virtual environment: python3 -m venv env
    Activate your virtual env: source venv/bin/activate
    Intall the project dependencies: pip install -r requirements.txt
    Install postgres, create a DB and replace the configurations in Django settings.
    Got inside the project directory.
    Apply migrations: python3 manage.py migrate
    Create superuser : python3 manage.py createsuperuser
    Start the local server: python3 manage.py runserver

ENDPOINTS

    GET, POST: /restaurants
    GET, DELETE: /restaurants/str:restaurant_id
    GET, POST: /restaurants/str:restaurant_id/recipes
    GET, DELETE: /restaurants/str:restaurant_id/recipes/str:recipe_id


    ----------------